# DL-Stream-V3

### If you are trying to lazy which you should not! (Deploying to Heroku)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/maderio/hlprnewww/master)
